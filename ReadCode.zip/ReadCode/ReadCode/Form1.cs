﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace ReadCode
{
    public partial class Form1 : Form
    {
        private string FilePath;
        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-B2H86DR;Initial Catalog=FileRead;User Id=sa;Password=Admin@123;");
        StreamWriter logWriter = new StreamWriter("C:\\Logs\\MyLogFile.txt", true);
        StreamWriter journalWriter = new StreamWriter("C:\\Logs\\MyJournal.txt", true);       


        public Form1()
        {
            InitializeComponent();
            FilePath = "";
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dr= openFileDialog2.ShowDialog();
            if(dr==DialogResult.OK)
            {
                FilePath = openFileDialog2.FileName;
            }
            else
            {
                FilePath = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            logWriter.WriteLine(DateTime.Now.ToString() + " - Starting execution of button2_Click");

            richTextBox1.Clear();
            if (FilePath == "")
            {
                MessageBox.Show("Please Select File");
                return;
            }


            StreamReader sr = new StreamReader(FilePath);
            int Count = 0;

            
            textFileClass objtbaleAvalabe = new textFileClass();
            if (objtbaleAvalabe.TableAvalabeOrNot("tblFileData") == false)
            {
                string[] data = File.ReadLines(FilePath).First().Split('\t');
                string createTableSql = "CREATE TABLE  tblFileData(" +
        string.Join(",", data.Select(h => "[" + h.Trim() + "] nvarchar(255)").ToArray()) +
        ")";
                connection.Open();
                SqlCommand createTableCmd = new SqlCommand(createTableSql, connection);
                createTableCmd.ExecuteNonQuery();
                connection.Close();

            }
            else
            {

                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    if (line.StartsWith("Snapdate"))
                    {
                        continue;
                    }

                    string[] data = line.Split('\t');

                    string Snapdate = data[0];
                    string PMSGroupID = data[1];
                    string RoomsBlocked = data[2];
                    string RoomRevenueBlocked = data[3];
                    string RoomsGroupNet = data[4];
                    string RoomRevenueGroupNet = data[5];
                    string RoomsPickedUp = data[6];
                    string RoomRevenuePickedUp = data[7];
                    string RoomsBlockedNPU = data[8];
                    string RoomRevenueBlockedNPU = data[9];
                    string PMSBuildingStatus = data[10];
                    string Rooms = data[11];
                    string RoomRevenue = data[12];
                    string Adults = data[13];
                    string RoomRevenueExtra2 = data[14];
                    string PMSLOS = data[15];
                    string PMSRoomNumber = data[16];
                    string PMSVIP = data[17];
                    string PMSPackage = data[18];
                    string PMSGuestType = data[19];
                    string Currency = data[20];
                    string SnapTime = data[21];


                    if (Snapdate != null)
                    {
                        richTextBox1.AppendText(Snapdate + "\n");
                        Count++;

                        textFileClass obj = new textFileClass();
                        obj.Snapdate = Snapdate;
                        obj.PMSGroupID = PMSGroupID;
                        obj.RoomsBlocked = RoomsBlocked;
                        obj.RoomRevenueBlocked = RoomRevenueBlocked;
                        obj.RoomsGroupNet = RoomsGroupNet;
                        obj.RoomRevenueGroupNet = RoomRevenueGroupNet;
                        obj.RoomsPickedUp = RoomsPickedUp;
                        obj.RoomRevenuePickedUp = RoomRevenuePickedUp;
                        obj.RoomsBlockedNPU = RoomsBlockedNPU;
                        obj.RoomRevenueBlockedNPU = RoomRevenueBlockedNPU;
                        obj.PMSBuildingStatus = PMSBuildingStatus;
                        obj.Rooms = Rooms;
                        obj.RoomRevenue = RoomRevenue;
                        obj.Adults = Adults;
                        obj.RoomRevenueExtra2 = RoomRevenueExtra2;
                        obj.PMSLOS = PMSLOS;
                        obj.PMSRoomNumber = PMSRoomNumber;
                        obj.PMSVIP = PMSVIP;
                        obj.PMSPackage = PMSPackage;
                        obj.PMSGuestType = PMSGuestType;
                        obj.Currency = Currency;
                        obj.SnapTime = SnapTime;
                        obj.Insertdata();

                    }


                }

                MessageBox.Show("Data Save Sucessfully !");

                sr.Close();

                logWriter.WriteLine(DateTime.Now.ToString() + " - Finished execution");
                journalWriter.WriteLine(DateTime.Now.ToString() + " - User opened the application");
                logWriter.Close();
                journalWriter.Close();

            }
        }



        




    }
}
