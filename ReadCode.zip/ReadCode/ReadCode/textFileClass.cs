﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ReadCode
{
   public class textFileClass
    {

        public string Snapdate { get; set; }
        public string PMSGroupID { get; set; }
        public string RoomsBlocked { get; set; }
        public string RoomRevenueBlocked { get; set; }
        public string RoomsGroupNet { get; set; }
        public string RoomRevenueGroupNet { get; set; }
        public string RoomsPickedUp { get; set; }
        public string RoomRevenuePickedUp { get; set; }
        public string RoomsBlockedNPU { get; set; }
        public string RoomRevenueBlockedNPU { get; set; }
        public string PMSBuildingStatus { get; set; }
        public string Rooms { get; set; }
        public string RoomRevenue { get; set; }
        public string Adults { get; set; }
        public string RoomRevenueExtra2 { get; set; }
        public string PMSLOS { get; set; }
        public string PMSRoomNumber { get; set; }
        public string PMSVIP { get; set; }
        public string PMSPackage { get; set; }
        public string PMSGuestType { get; set; }
        public string Currency { get; set; }
        public string SnapTime { get; set; }

        //string connectionString = "Data Source=DESKTOP-B2H86DR;Initial Catalog=FileRead;User Id=sa;Password=Admin@123;";
        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-B2H86DR;Initial Catalog=FileRead;User Id=sa;Password=Admin@123;");


        public void Insertdata()
        {
            try
            {
                
                connection.Open();
                SqlCommand cmd = new SqlCommand("sp_InsertData", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Snapdate", Snapdate);
                cmd.Parameters.AddWithValue("@PMSGroupID", PMSGroupID);
                cmd.Parameters.AddWithValue("@RoomsBlocked", RoomsBlocked);
                cmd.Parameters.AddWithValue("@RoomRevenueBlocked", RoomRevenueBlocked);
                cmd.Parameters.AddWithValue("@RoomsGroupNet", RoomsGroupNet);
                cmd.Parameters.AddWithValue("@RoomRevenueGroupNet", RoomRevenueGroupNet);
                cmd.Parameters.AddWithValue("@RoomsPickedUp", RoomsPickedUp);
                cmd.Parameters.AddWithValue("@RoomRevenuePickedUp", RoomRevenuePickedUp);
                cmd.Parameters.AddWithValue("@RoomsBlockedNPU", RoomsBlockedNPU);
                cmd.Parameters.AddWithValue("@RoomRevenueBlockedNPU", RoomRevenueBlockedNPU);
                cmd.Parameters.AddWithValue("@PMSBuildingStatus", PMSBuildingStatus);
                cmd.Parameters.AddWithValue("@Rooms", Rooms);
                cmd.Parameters.AddWithValue("@RoomRevenue", RoomRevenue);
                cmd.Parameters.AddWithValue("@Adults", Adults);
                cmd.Parameters.AddWithValue("@RoomRevenueExtra2", RoomRevenueExtra2);
                cmd.Parameters.AddWithValue("@PMSLOS", PMSLOS);
                cmd.Parameters.AddWithValue("@PMSRoomNumber", PMSRoomNumber);
                cmd.Parameters.AddWithValue("@PMSVIP", PMSVIP);
                cmd.Parameters.AddWithValue("@PMSPackage", PMSPackage);
                cmd.Parameters.AddWithValue("@PMSGuestType", PMSGuestType);
                cmd.Parameters.AddWithValue("@Currency", Currency);
                cmd.Parameters.AddWithValue("@SnapTime", SnapTime);
                cmd.ExecuteNonQuery();
                connection.Close();


            }
            catch (Exception ex)
            {

            }

        }

        public bool TableAvalabeOrNot(string tableName)
        {
           
            bool result = false;
            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @TableName", connection);
                cmd.Parameters.AddWithValue("@TableName", tableName);
                int count = (int)cmd.ExecuteScalar();
                result = count == 0 ? false : true;
                connection.Close();
            }
            catch (Exception ex)
            {

            }
            return result;
        }


    }
}
